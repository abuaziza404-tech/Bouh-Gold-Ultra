class SpectralIndices {
  final bool hasRawBands;
  final double? ironIndex;
  final double? quartzIndex;
  final double? alterationIndex;
  final double? ndmi;
  final String note;

  const SpectralIndices({
    required this.hasRawBands,
    required this.ironIndex,
    required this.quartzIndex,
    required this.alterationIndex,
    required this.ndmi,
    required this.note,
  });
}
