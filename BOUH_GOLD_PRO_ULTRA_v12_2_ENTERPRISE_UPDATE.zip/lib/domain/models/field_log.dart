class FieldLog {
  final String id;
  final String targetId;
  final String title;
  final double latitude;
  final double longitude;
  final String observation;
  final String decision;
  final DateTime createdAt;

  const FieldLog({required this.id, required this.targetId, required this.title, required this.latitude, required this.longitude, required this.observation, required this.decision, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'id': id,
        'target_id': targetId,
        'title': title,
        'latitude': latitude,
        'longitude': longitude,
        'observation': observation,
        'decision': decision,
        'created_at': createdAt.toIso8601String(),
      };

  factory FieldLog.fromJson(Map<String, dynamic> json) => FieldLog(
        id: '${json['id']}',
        targetId: '${json['target_id']}',
        title: '${json['title']}',
        latitude: (json['latitude'] as num?)?.toDouble() ?? 0,
        longitude: (json['longitude'] as num?)?.toDouble() ?? 0,
        observation: '${json['observation']}',
        decision: '${json['decision']}',
        createdAt: DateTime.tryParse('${json['created_at']}') ?? DateTime.now(),
      );
}
