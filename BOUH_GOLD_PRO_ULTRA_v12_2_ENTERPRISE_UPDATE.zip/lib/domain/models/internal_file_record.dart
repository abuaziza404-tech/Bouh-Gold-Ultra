class InternalFileRecord {
  final String id;
  final String name;
  final String path;
  final String kind;
  final int bytes;
  final DateTime createdAt;

  const InternalFileRecord({required this.id, required this.name, required this.path, required this.kind, required this.bytes, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'path': path,
        'kind': kind,
        'bytes': bytes,
        'created_at': createdAt.toIso8601String(),
      };

  factory InternalFileRecord.fromJson(Map<String, dynamic> json) => InternalFileRecord(
        id: '${json['id']}',
        name: '${json['name']}',
        path: '${json['path']}',
        kind: '${json['kind']}',
        bytes: (json['bytes'] as num?)?.toInt() ?? 0,
        createdAt: DateTime.tryParse('${json['created_at']}') ?? DateTime.now(),
      );
}
