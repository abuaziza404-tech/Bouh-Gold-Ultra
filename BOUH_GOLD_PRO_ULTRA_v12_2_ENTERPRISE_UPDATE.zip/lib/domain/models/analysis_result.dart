import 'gpz_recommendation.dart';
import 'spectral_indices.dart';
import 'target_cell.dart';

class AnalysisResult {
  final TargetCell? cell;
  final double tappedLatitude;
  final double tappedLongitude;
  final double distanceMeters;
  final bool outsidePack;
  final String decision;
  final String title;
  final String explanation;
  final double ipi;
  final double pScore;
  final List<String> triggeredGates;
  final SpectralIndices spectral;
  final GpzRecommendation gpz;

  const AnalysisResult({
    required this.cell,
    required this.tappedLatitude,
    required this.tappedLongitude,
    required this.distanceMeters,
    required this.outsidePack,
    required this.decision,
    required this.title,
    required this.explanation,
    required this.ipi,
    required this.pScore,
    required this.triggeredGates,
    required this.spectral,
    required this.gpz,
  });

  bool get isReject => decision == 'Reject';
  bool get isTargetB => decision == 'Target-B Elite';
  bool get isHold => decision.contains('HOLD') || decision == 'Outside Pack';
}
