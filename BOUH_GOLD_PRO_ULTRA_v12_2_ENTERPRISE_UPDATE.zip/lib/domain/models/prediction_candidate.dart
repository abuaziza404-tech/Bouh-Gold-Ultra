class PredictionCandidate {
  final String id;
  final String name;
  final double latitude;
  final double longitude;
  final double ipi;
  final double pScore;
  final String decision;
  final String reason;
  final String nextAction;

  const PredictionCandidate({required this.id, required this.name, required this.latitude, required this.longitude, required this.ipi, required this.pScore, required this.decision, required this.reason, required this.nextAction});

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'latitude': latitude,
        'longitude': longitude,
        'ipi': ipi,
        'p_score': pScore,
        'decision': decision,
        'reason': reason,
        'next_action': nextAction,
      };
}
