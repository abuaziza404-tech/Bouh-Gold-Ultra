class AppProject {
  final String id;
  final String name;
  final String region;
  final String description;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int targetCount;
  final int layerCount;
  final String status;

  const AppProject({
    required this.id,
    required this.name,
    required this.region,
    required this.description,
    required this.createdAt,
    required this.updatedAt,
    required this.targetCount,
    required this.layerCount,
    required this.status,
  });

  factory AppProject.seed() => AppProject(
        id: 'project_red_sea_hills_master',
        name: 'مشروع بوح التضاريس — Red Sea Hills',
        region: 'Gebeit–Sinkat / Ariab / Arbaat / Hashai',
        description: 'مشروع ميداني Offline-first لإدارة أهداف الذهب، طبقات الخرائط، ملفات الحزمة، ومساعد BOUH المحلي.',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        targetCount: 0,
        layerCount: 0,
        status: 'Active',
      );

  AppProject copyWith({String? id, String? name, String? region, String? description, DateTime? createdAt, DateTime? updatedAt, int? targetCount, int? layerCount, String? status}) {
    return AppProject(
      id: id ?? this.id,
      name: name ?? this.name,
      region: region ?? this.region,
      description: description ?? this.description,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      targetCount: targetCount ?? this.targetCount,
      layerCount: layerCount ?? this.layerCount,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'region': region,
        'description': description,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'target_count': targetCount,
        'layer_count': layerCount,
        'status': status,
      };

  factory AppProject.fromJson(Map<String, dynamic> json) => AppProject(
        id: '${json['id']}',
        name: '${json['name']}',
        region: '${json['region']}',
        description: '${json['description']}',
        createdAt: DateTime.tryParse('${json['created_at']}') ?? DateTime.now(),
        updatedAt: DateTime.tryParse('${json['updated_at']}') ?? DateTime.now(),
        targetCount: (json['target_count'] as num?)?.toInt() ?? 0,
        layerCount: (json['layer_count'] as num?)?.toInt() ?? 0,
        status: '${json['status'] ?? 'Active'}',
      );
}
