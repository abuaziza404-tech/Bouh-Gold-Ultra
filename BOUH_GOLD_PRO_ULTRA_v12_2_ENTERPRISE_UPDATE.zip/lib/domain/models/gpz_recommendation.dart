class GpzRecommendation {
  final String groundType;
  final String goldMode;
  final String sensitivity;
  final String audioSmoothing;
  final String swingStrategy;
  final String reason;

  const GpzRecommendation({
    required this.groundType,
    required this.goldMode,
    required this.sensitivity,
    required this.audioSmoothing,
    required this.swingStrategy,
    required this.reason,
  });
}
