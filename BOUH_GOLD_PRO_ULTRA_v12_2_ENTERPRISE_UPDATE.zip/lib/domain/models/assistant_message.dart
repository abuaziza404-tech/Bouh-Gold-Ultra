class AssistantMessage {
  final String id;
  final bool fromUser;
  final String text;
  final DateTime createdAt;

  const AssistantMessage({required this.id, required this.fromUser, required this.text, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'id': id,
        'from_user': fromUser,
        'text': text,
        'created_at': createdAt.toIso8601String(),
      };

  factory AssistantMessage.fromJson(Map<String, dynamic> json) => AssistantMessage(
        id: '${json['id']}',
        fromUser: json['from_user'] == true,
        text: '${json['text']}',
        createdAt: DateTime.tryParse('${json['created_at']}') ?? DateTime.now(),
      );
}
