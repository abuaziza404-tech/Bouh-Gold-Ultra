import 'dart:convert';

import '../data/services/app_storage_service.dart';
import '../domain/models/prediction_candidate.dart';
import '../domain/models/target_cell.dart';

class ExportEngine {
  final AppStorageService storage;
  ExportEngine(this.storage);

  Future<String> exportTargetsCsv(List<TargetCell> targets) async {
    final buffer = StringBuffer('id,name,latitude,longitude,belt,type,ipi,p_score,status,source\n');
    for (final t in targets) {
      buffer.writeln([t.id, _csv(t.name), t.latitude, t.longitude, _csv(t.belt), _csv(t.type), t.scores['IPI'] ?? 0, t.scores['PScore'] ?? 0, _csv(t.status), _csv(t.source)].join(','));
    }
    final name = 'exports/targets_${DateTime.now().millisecondsSinceEpoch}.csv';
    await storage.writeText(name, buffer.toString());
    return name;
  }

  Future<String> exportPredictionsGeoJson(List<PredictionCandidate> predictions) async {
    final fc = {
      'type': 'FeatureCollection',
      'features': predictions.map((p) => {
        'type': 'Feature',
        'properties': p.toJson(),
        'geometry': {'type': 'Point', 'coordinates': [p.longitude, p.latitude]},
      }).toList(),
    };
    final name = 'exports/predictions_${DateTime.now().millisecondsSinceEpoch}.geojson';
    await storage.writeText(name, const JsonEncoder.withIndent('  ').convert(fc));
    return name;
  }

  Future<String> exportTargetsKml(List<TargetCell> targets) async {
    final kml = StringBuffer();
    kml.writeln('<?xml version="1.0" encoding="UTF-8"?>');
    kml.writeln('<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>BOUH Targets v12.2</name>');
    for (final t in targets) {
      final ipi = (t.scores['IPI'] ?? 0).toStringAsFixed(1);
      kml.writeln('<Placemark><name>${_xml(t.name)} [$ipi]</name><description><![CDATA[ID: ${_xml(t.id)}<br/>Belt: ${_xml(t.belt)}<br/>Status: ${_xml(t.status)}<br/>IPI: $ipi<br/>Note: ${_xml(t.note)}]]></description><Point><coordinates>${t.longitude},${t.latitude},0</coordinates></Point></Placemark>');
    }
    kml.writeln('</Document></kml>');
    final name = 'exports/targets_${DateTime.now().millisecondsSinceEpoch}.kml';
    await storage.writeText(name, kml.toString());
    return name;
  }

  String _csv(Object? value) {
    final s = '${value ?? ''}'.replaceAll('"', '""');
    return '"$s"';
  }

  String _xml(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
