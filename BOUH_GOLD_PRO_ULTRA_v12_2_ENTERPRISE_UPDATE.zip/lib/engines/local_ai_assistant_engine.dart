import '../data/repositories/analysis_repository.dart';
import '../domain/models/analysis_result.dart';
import '../domain/models/prediction_candidate.dart';
import '../domain/models/target_cell.dart';
import 'predictive_engine.dart';

class LocalAiAssistantEngine {
  final PredictiveEngine predictiveEngine;
  LocalAiAssistantEngine(this.predictiveEngine);

  String answer({required String prompt, required AnalysisRepository repository, required List<PredictionCandidate> predictions, AnalysisResult? lastResult}) {
    final text = prompt.trim().toLowerCase();
    if (text.isEmpty) return 'اكتب أمرًا مثل: أفضل هدف، تحليل 19.6045911 36.9171953، GPZ، الطبقات، التصدير.';

    final coords = _extractCoordinates(text);
    if (coords != null) {
      final r = repository.analyzePoint(coords.$1, coords.$2);
      return _analysisReply(r);
    }

    if (_has(text, ['أفضل', 'افضل', 'اغنى', 'أغنى', 'target', 'هدف'])) {
      final list = predictions.isEmpty ? predictiveEngine.generateCandidates(repository.cells, limit: 5) : predictions.take(5).toList();
      if (list.isEmpty) return 'لا توجد أهداف محملة بعد. افتح الحزمة أو أعد تشغيل التطبيق.';
      final b = StringBuffer('أقوى المرشحات داخل الحزمة الحالية:\n');
      for (var i = 0; i < list.length; i++) {
        final p = list[i];
        b.writeln('${i + 1}) ${p.name} — ${p.decision} — IPI ${p.ipi.toStringAsFixed(1)} — ${p.nextAction}');
      }
      b.writeln('\nلا يوجد إثبات اقتصادي قبل Field Validation + Assay + QA/QC.');
      return b.toString();
    }

    if (_has(text, ['gpz', '7000', 'جهاز', 'الحساسية'])) {
      final r = lastResult;
      if (r == null) return 'اضغط نقطة أولاً لأعطيك إعدادات GPZ 7000 حسب magnetic risk والكوارتز.';
      return 'إعداد GPZ للنقطة الأخيرة:\nGround Type: ${r.gpz.groundType}\nGold Mode: ${r.gpz.goldMode}\nSensitivity: ${r.gpz.sensitivity}\nAudio Smoothing: ${r.gpz.audioSmoothing}\nSwing: ${r.gpz.swingStrategy}\nالسبب: ${r.gpz.reason}';
    }

    if (_has(text, ['طبقات', 'layer', 'خرائط', 'map'])) {
      return 'نظام الطبقات يدعم: AOI، lineaments، targets، heat/risk overlay، وإضافة GeoJSON/KML كنص داخلي محفوظ. فعّل/عطّل الطبقات من تبويب الطبقات.';
    }

    if (_has(text, ['تصدير', 'export', 'kml', 'csv', 'geojson'])) {
      return 'افتح تبويب الملفات واضغط: تصدير KML أو CSV أو GeoJSON. سيتم حفظ الملفات داخل مساحة التطبيق الداخلية في مجلد exports.';
    }

    if (_has(text, ['رفض', 'kill', 'matrix', 'بوابات'])) {
      return 'القانون الحاكم: No Structure = Reject، No Pattern = Reject/HOLD، No Clay/SWIR = HOLD، FeOx alone = Reject، وأقل من 3 مؤشرات ضمن 250م = Downgrade.';
    }

    if (_has(text, ['مشروع', 'إدارة', 'ادارة', 'نظام'])) {
      return 'المشروع الحالي يعمل كمساحة داخلية: مشاريع، طبقات، ملفات، صادرات، Field Logs، وذاكرة أوامر المساعد. يمكنك إنشاء مشروع جديد من تبويب النظام.';
    }

    return 'فهمت طلبك. كمساعد BOUH المحلي أعمل Offline على قواعد المشروع: Structure → Pattern → Alteration → Confirmation → Decision. الأوامر الجاهزة: أفضل هدف، تحليل إحداثية، GPZ، الطبقات، التصدير، بوابات القتل، إدارة مشروع.';
  }

  String _analysisReply(AnalysisResult r) {
    final name = r.cell?.name ?? 'نقطة غير مرتبطة';
    return 'تحليل النقطة: $name\nالقرار: ${r.decision}\nIPI: ${r.ipi.toStringAsFixed(1)}\nP-Score: ${r.pScore.toStringAsFixed(1)}\nالمسافة لأقرب خلية: ${r.distanceMeters.toStringAsFixed(1)}م\n${r.explanation}\nGPZ: ${r.gpz.groundType} / ${r.gpz.goldMode} / حساسية ${r.gpz.sensitivity}';
  }

  bool _has(String text, List<String> words) => words.any(text.contains);

  (double, double)? _extractCoordinates(String text) {
    final matches = RegExp(r'[-+]?\d{1,2}\.\d+').allMatches(text).map((m) => double.tryParse(m.group(0)!)).whereType<double>().toList();
    if (matches.length >= 2) {
      final a = matches[0];
      final b = matches[1];
      if (a.abs() <= 90 && b.abs() <= 180) return (a, b);
      if (b.abs() <= 90 && a.abs() <= 180) return (b, a);
    }
    return null;
  }
}
