import '../domain/models/prediction_candidate.dart';
import '../domain/models/target_cell.dart';

class PredictiveEngine {
  List<PredictionCandidate> generateCandidates(List<TargetCell> cells, {int limit = 12}) {
    final scored = <PredictionCandidate>[];
    for (final cell in cells) {
      final gates = cell.gates;
      final structure = _yes(gates['structure']);
      final pattern = _yes(gates['pattern']);
      final swir = _yes(gates['swir_clay']);
      final quartz = _yes(gates['quartz_carrier']);
      final field = _yes(gates['field_evidence']);
      final unknownSwir = _unknown(gates['swir_clay']);
      final ipi = cell.scores['IPI'] ?? 0;
      final pScore = cell.scores['PScore'] ?? 0;

      String decision;
      String reason;
      String action;
      if (!structure) {
        decision = 'Reject';
        reason = 'البنية غير مؤكدة؛ No Structure يمنع الترقية.';
        action = 'أعد قراءة lineaments قبل أي عمل.';
      } else if (!pattern) {
        decision = 'Low HOLD';
        reason = 'البنية موجودة لكن المصيدة/النمط غير مثبت.';
        action = 'ابحث عن jog/intersection/contact داخل 250م.';
      } else if (unknownSwir || !swir) {
        decision = 'SWIR HOLD';
        reason = 'هيكل ونمط موجودان لكن SWIR/Clay يحتاج إثبات باندات أو شاهد كوارتز.';
        action = 'أدخل B04/B08/B11/B12 أو أضف ملاحظة field quartz/gossan.';
      } else if (ipi >= 85 && field) {
        decision = 'Target-B Candidate';
        reason = 'تراكب قوي: Structure + Pattern + Alteration + Field.';
        action = 'Trench موجه + channel sampling + QA/QC.';
      } else if (ipi >= 70 || (structure && pattern && (swir || quartz))) {
        decision = 'Candidate';
        reason = 'احتمالية جيدة تحتاج تحقق ميداني.';
        action = 'GPZ grid 20×20م ثم عينات سطحية.';
      } else {
        decision = 'Review';
        reason = 'نقطة سياقية مفيدة للربط الإقليمي وليست أولوية حفر.';
        action = 'احتفظ بها كطبقة مرجعية.';
      }

      scored.add(PredictionCandidate(
        id: 'PRED-${cell.id}',
        name: cell.name,
        latitude: cell.latitude,
        longitude: cell.longitude,
        ipi: ipi,
        pScore: pScore,
        decision: decision,
        reason: reason,
        nextAction: action,
      ));
    }
    scored.sort((a, b) {
      final ai = _rank(a.decision) * 1000 + a.ipi + a.pScore * 0.25;
      final bi = _rank(b.decision) * 1000 + b.ipi + b.pScore * 0.25;
      return bi.compareTo(ai);
    });
    return scored.take(limit).toList(growable: false);
  }

  bool _yes(String? v) {
    final s = '${v ?? ''}'.toLowerCase();
    return s == 'yes' || s == 'partial' || s == 'true';
  }

  bool _unknown(String? v) {
    final s = '${v ?? ''}'.toLowerCase().trim();
    return s.isEmpty || s == 'unknown' || s == 'pending' || s == 'null';
  }

  int _rank(String decision) {
    if (decision.contains('Target-B')) return 5;
    if (decision == 'Candidate') return 4;
    if (decision.contains('SWIR')) return 3;
    if (decision.contains('HOLD')) return 2;
    if (decision == 'Review') return 1;
    return 0;
  }
}
