import '../domain/models/spectral_indices.dart';

class SpectralEngine {
  SpectralIndices compute(Map<String, dynamic> spectral) {
    final hasRawBands = spectral['has_raw_bands'] == true;
    if (!hasRawBands) {
      return const SpectralIndices(
        hasRawBands: false,
        ironIndex: null,
        quartzIndex: null,
        alterationIndex: null,
        ndmi: null,
        note: 'لا توجد باندات خام داخل هذه الخلية. هذه نقطة حقيقية من سجل المشروع، لكن SWIR/Clay غير مؤكد حتى إدخال B04/B08/B11/B12 أو GeoTIFF.',
      );
    }

    double? v(String key) {
      final value = spectral[key];
      if (value is num) return value.toDouble();
      return null;
    }

    final b2 = v('B2');
    final b4 = v('B4');
    final b8 = v('B8');
    final b11 = v('B11');
    final b12 = v('B12');
    double? safeDiv(double? a, double? b) => a == null || b == null || b.abs() < 1e-9 ? null : a / b;

    final iron = safeDiv(b4, b2);
    final quartz = safeDiv(b11, b12);
    final alteration = b11 == null || b12 == null || b8 == null || b8.abs() < 1e-9 ? null : (b11 + b12) / b8;
    final ndmi = b8 == null || b11 == null || (b8 + b11).abs() < 1e-9 ? null : (b8 - b11) / (b8 + b11);

    return SpectralIndices(
      hasRawBands: true,
      ironIndex: iron,
      quartzIndex: quartz,
      alterationIndex: alteration,
      ndmi: ndmi,
      note: 'تم الحساب من الباندات الخام: Iron=B4/B2, Quartz=B11/B12, Alteration=(B11+B12)/B8, NDMI=(B8-B11)/(B8+B11).',
    );
  }
}
