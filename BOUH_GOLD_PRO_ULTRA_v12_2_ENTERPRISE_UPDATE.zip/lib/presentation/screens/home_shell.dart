import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';
import 'assistant_screen.dart';
import 'dashboard_screen.dart';
import 'files_screen.dart';
import 'layers_screen.dart';
import 'map_screen.dart';
import 'system_screen.dart';

class HomeShell extends StatelessWidget {
  const HomeShell({super.key});

  static const _pages = [
    MapScreen(),
    DashboardScreen(),
    LayersScreen(),
    FilesScreen(),
    AssistantScreen(),
    SystemScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      if (controller.loading) {
        return const Scaffold(body: Center(child: CircularProgressIndicator(color: Color(0xFFFFD700))));
      }
      if (controller.error != null) {
        return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('تعذر تشغيل النظام: ${controller.error}', textAlign: TextAlign.center))));
      }
      return Scaffold(
        body: _pages[controller.tabIndex],
        bottomNavigationBar: NavigationBar(
          height: 70,
          selectedIndex: controller.tabIndex,
          onDestinationSelected: controller.setTab,
          backgroundColor: const Color(0xEE101010),
          indicatorColor: const Color(0x33FFD700),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map, color: Color(0xFFFFD700)), label: 'الخريطة'),
            NavigationDestination(icon: Icon(Icons.radar_outlined), selectedIcon: Icon(Icons.radar, color: Color(0xFFFFD700)), label: 'التنبؤ'),
            NavigationDestination(icon: Icon(Icons.layers_outlined), selectedIcon: Icon(Icons.layers, color: Color(0xFFFFD700)), label: 'الطبقات'),
            NavigationDestination(icon: Icon(Icons.folder_open), selectedIcon: Icon(Icons.folder, color: Color(0xFFFFD700)), label: 'الملفات'),
            NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), selectedIcon: Icon(Icons.psychology_alt, color: Color(0xFFFFD700)), label: 'AI'),
            NavigationDestination(icon: Icon(Icons.tune), selectedIcon: Icon(Icons.settings, color: Color(0xFFFFD700)), label: 'النظام'),
          ],
        ),
      );
    });
  }
}
