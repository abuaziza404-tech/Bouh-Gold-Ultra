import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';
import '../widgets/analysis_bottom_sheet.dart';
import '../widgets/offline_map_canvas.dart';

class MapScreen extends StatelessWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      final bounds = controller.analysisRepository.manifest['bounds'] as Map<String, dynamic>? ?? const {'north': 22.05, 'south': 18.6, 'east': 37.2, 'west': 35.0};
      return Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(
                child: OfflineMapCanvas(
                  targets: controller.targets,
                  layers: controller.allDrawableLayers,
                  north: (bounds['north'] as num).toDouble(),
                  south: (bounds['south'] as num).toDouble(),
                  east: (bounds['east'] as num).toDouble(),
                  west: (bounds['west'] as num).toDouble(),
                  onTap: (lat, lon) {
                    final result = controller.analyze(lat, lon);
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => FractionallySizedBox(heightFactor: 0.90, child: AnalysisBottomSheet(result: result)),
                    );
                  },
                ),
              ),
              Positioned(top: 16, left: 16, right: 16, child: _Header(controller: controller)),
              Positioned(bottom: 18, left: 18, right: 18, child: _QuickBar(controller: controller)),
            ],
          ),
        ),
      );
    });
  }
}

class _Header extends StatelessWidget {
  final AppController controller;
  const _Header({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xEE101010), borderRadius: BorderRadius.circular(26), border: Border.all(color: const Color(0x99FFD700))),
      child: Column(children: [
        Row(children: [
          const Icon(Icons.public, color: Color(0xFFFFD700)),
          const SizedBox(width: 8),
          const Expanded(child: Text('BOUH GOLD PRO ULTRA v12.2', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w900, fontSize: 19))),
          IconButton(onPressed: () => controller.setTab(4), icon: const Icon(Icons.psychology_alt, color: Color(0xFFFFD700))),
        ]),
        const Text('Enterprise Offline Field OS — خرائط + طبقات + مساعد داخلي', style: TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 10),
        Row(children: [
          _chip('Elite', 'elite'),
          _chip('أعلى IPI', 'ipi'),
          _chip('P-Score', 'pscore'),
          _chip('الكل', 'nearest'),
        ]),
      ]),
    );
  }

  Widget _chip(String label, String mode) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: ChoiceChip(
            selected: controller.sortMode == mode,
            label: Text(label, overflow: TextOverflow.ellipsis),
            selectedColor: const Color(0x33FFD700),
            side: BorderSide(color: controller.sortMode == mode ? const Color(0xFFFFD700) : Colors.white24),
            onSelected: (_) => controller.setSortMode(mode),
          ),
        ),
      );
}

class _QuickBar extends StatelessWidget {
  final AppController controller;
  const _QuickBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: const Color(0xEE101010), borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white10)),
      child: Row(children: [
        Expanded(child: Text('أهداف: ${controller.targets.length}  |  طبقات: ${controller.layers.length}  |  تنبؤات: ${controller.predictions.length}', style: const TextStyle(color: Colors.white70, fontSize: 12))),
        IconButton(onPressed: controller.refreshPredictions, icon: const Icon(Icons.auto_graph, color: Color(0xFFFFD700))),
        IconButton(onPressed: () => controller.setTab(2), icon: const Icon(Icons.layers, color: Colors.white)),
        IconButton(onPressed: () => controller.setTab(3), icon: const Icon(Icons.folder, color: Colors.white)),
      ]),
    );
  }
}
