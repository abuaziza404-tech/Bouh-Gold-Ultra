import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';

class LayersScreen extends StatelessWidget {
  const LayersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      return Scaffold(
        appBar: AppBar(title: const Text('إدارة الخرائط والطبقات'), actions: [IconButton(onPressed: () => _addLayerDialog(context, controller), icon: const Icon(Icons.add))]),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _info(),
            const SizedBox(height: 12),
            const Text('الطبقات الداخلية', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.w900)),
            _builtin('AOI Regions', 'حدود التشغيل الإقليمية والمربعات المرجعية', true),
            _builtin('Lineaments', 'اتجاهات بنيوية مرجعية من الحزمة', true),
            const SizedBox(height: 14),
            const Text('طبقات المستخدم', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.w900)),
            if (controller.layers.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('لم تضف طبقات بعد. اضغط + لإدخال GeoJSON أو KML كنص داخلي محفوظ.', style: TextStyle(color: Colors.white60))),
            for (final layer in controller.layers)
              Card(
                color: const Color(0xFF0C120D),
                child: SwitchListTile(
                  value: layer.enabled,
                  onChanged: (_) => controller.toggleLayer(layer.id),
                  title: Text(layer.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${layer.type} | ${layer.featureCount} feature | ${layer.source}', style: const TextStyle(color: Colors.white60)),
                  secondary: const Icon(Icons.layers, color: Color(0xFFFFD700)),
                ),
              ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(onPressed: () => _addLayerDialog(context, controller), icon: const Icon(Icons.add), label: const Text('إضافة طبقة')),
      );
    });
  }

  Widget _info() => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(22)), child: const Text('يمكن إضافة طبقات GeoJSON/KML داخلية كنص، تحفظ في مساحة التطبيق وتظهر فوق خريطة Offline Canvas. الحزمة لا تحتاج إنترنت.', style: TextStyle(color: Colors.white70)));

  Widget _builtin(String name, String desc, bool enabled) => Card(color: const Color(0xFF0C120D), child: ListTile(leading: const Icon(Icons.verified, color: Color(0xFFFFD700)), title: Text(name), subtitle: Text(desc, style: const TextStyle(color: Colors.white60)), trailing: const Icon(Icons.lock, color: Colors.white38)));

  Future<void> _addLayerDialog(BuildContext context, AppController controller) async {
    final name = TextEditingController(text: 'طبقة جديدة');
    final type = TextEditingController(text: 'geojson');
    final content = TextEditingController(text: '{"type":"FeatureCollection","features":[]}');
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إضافة طبقة داخلية'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الطبقة')),
          TextField(controller: type, decoration: const InputDecoration(labelText: 'النوع: geojson أو kml')),
          const SizedBox(height: 8),
          TextField(controller: content, minLines: 6, maxLines: 12, decoration: const InputDecoration(labelText: 'محتوى GeoJSON/KML', border: OutlineInputBorder())),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () async { await controller.addLayer(name.text, type.text, content.text); if (context.mounted) Navigator.pop(context); }, child: const Text('حفظ')),
        ],
      ),
    );
  }
}
