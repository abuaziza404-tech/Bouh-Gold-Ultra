import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../domain/models/map_layer.dart';
import '../../domain/models/target_cell.dart';

class OfflineMapCanvas extends StatelessWidget {
  final List<TargetCell> targets;
  final List<MapLayer> layers;
  final void Function(double lat, double lon) onTap;
  final double north;
  final double south;
  final double east;
  final double west;

  const OfflineMapCanvas({
    super.key,
    required this.targets,
    required this.layers,
    required this.onTap,
    required this.north,
    required this.south,
    required this.east,
    required this.west,
  });

  Offset _project(double lat, double lon, Size size) {
    final x = ((lon - west) / (east - west)).clamp(0.0, 1.0) * size.width;
    final y = ((north - lat) / (north - south)).clamp(0.0, 1.0) * size.height;
    return Offset(x, y);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        return GestureDetector(
          onTapDown: (details) {
            final dx = details.localPosition.dx.clamp(0.0, size.width);
            final dy = details.localPosition.dy.clamp(0.0, size.height);
            final lon = west + (dx / size.width) * (east - west);
            final lat = north - (dy / size.height) * (north - south);
            onTap(lat, lon);
          },
          child: CustomPaint(
            size: size,
            painter: _OfflineMapPainter(
              targets: targets,
              layers: layers,
              north: north,
              south: south,
              east: east,
              west: west,
              project: _project,
            ),
          ),
        );
      },
    );
  }
}

class _OfflineMapPainter extends CustomPainter {
  final List<TargetCell> targets;
  final List<MapLayer> layers;
  final double north;
  final double south;
  final double east;
  final double west;
  final Offset Function(double lat, double lon, Size size) project;

  _OfflineMapPainter({required this.targets, required this.layers, required this.north, required this.south, required this.east, required this.west, required this.project});

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFF050806), Color(0xFF07140A), Color(0xFF12100A)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);
    _drawGrid(canvas, size);
    _drawTerrainNoise(canvas, size);
    _drawLayers(canvas, size);
    _drawTargets(canvas, size);
    _drawLegend(canvas, size);
  }

  void _drawGrid(Canvas canvas, Size size) {
    final gridPaint = Paint()..color = const Color(0x22FFD700)..strokeWidth = 0.6;
    for (var i = 1; i < 9; i++) {
      final x = size.width * i / 9;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (var i = 1; i < 13; i++) {
      final y = size.height * i / 13;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
  }

  void _drawTerrainNoise(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.0..color = const Color(0x1AFFFFFF);
    for (var i = 0; i < 18; i++) {
      final path = Path();
      final yBase = size.height * (0.08 + i * 0.052);
      path.moveTo(0, yBase);
      for (var x = 0.0; x <= size.width; x += 22) {
        final y = yBase + math.sin((x * 0.018) + i * 0.75) * (8 + i % 4) + math.cos(x * 0.006 + i) * 12;
        path.lineTo(x, y);
      }
      canvas.drawPath(path, p);
    }
  }

  void _drawLayers(Canvas canvas, Size size) {
    for (final layer in layers) {
      final color = layer.id.contains('line') ? const Color(0xFF38BDF8) : layer.id.contains('aoi') ? const Color(0xFFFFD700) : const Color(0xFF9F7AEA);
      final linePaint = Paint()..color = color.withOpacity(layer.source == 'asset' ? 0.42 : 0.75)..style = PaintingStyle.stroke..strokeWidth = layer.source == 'asset' ? 1.4 : 2.0;
      final fillPaint = Paint()..color = color.withOpacity(0.06)..style = PaintingStyle.fill;
      final features = _parseFeatures(layer.content);
      for (final geometry in features) {
        final type = geometry['type'];
        final coordinates = geometry['coordinates'];
        if (type == 'Point' && coordinates is List && coordinates.length >= 2) {
          final offset = project((coordinates[1] as num).toDouble(), (coordinates[0] as num).toDouble(), size);
          canvas.drawCircle(offset, 5, Paint()..color = color.withOpacity(0.75));
        } else if (type == 'LineString' && coordinates is List) {
          _drawLine(canvas, size, coordinates, linePaint);
        } else if (type == 'Polygon' && coordinates is List && coordinates.isNotEmpty) {
          final ring = coordinates.first;
          if (ring is List) _drawPolygon(canvas, size, ring, linePaint, fillPaint);
        } else if (type == 'MultiLineString' && coordinates is List) {
          for (final line in coordinates) {
            if (line is List) _drawLine(canvas, size, line, linePaint);
          }
        }
      }
    }
  }

  void _drawLine(Canvas canvas, Size size, List coords, Paint paint) {
    if (coords.length < 2) return;
    final path = Path();
    var started = false;
    for (final c in coords) {
      if (c is List && c.length >= 2 && c[0] is num && c[1] is num) {
        final o = project((c[1] as num).toDouble(), (c[0] as num).toDouble(), size);
        if (!started) { path.moveTo(o.dx, o.dy); started = true; } else { path.lineTo(o.dx, o.dy); }
      }
    }
    canvas.drawPath(path, paint);
  }

  void _drawPolygon(Canvas canvas, Size size, List coords, Paint line, Paint fill) {
    if (coords.length < 3) return;
    final path = Path();
    var started = false;
    for (final c in coords) {
      if (c is List && c.length >= 2 && c[0] is num && c[1] is num) {
        final o = project((c[1] as num).toDouble(), (c[0] as num).toDouble(), size);
        if (!started) { path.moveTo(o.dx, o.dy); started = true; } else { path.lineTo(o.dx, o.dy); }
      }
    }
    path.close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, line);
  }

  List<Map<String, dynamic>> _parseFeatures(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        if (decoded['type'] == 'FeatureCollection' && decoded['features'] is List) {
          return (decoded['features'] as List)
              .whereType<Map>()
              .map((f) => f['geometry'])
              .whereType<Map>()
              .map((g) => g.cast<String, dynamic>())
              .toList();
        }
        if (decoded['type'] == 'Feature' && decoded['geometry'] is Map) return [(decoded['geometry'] as Map).cast<String, dynamic>()];
        if (decoded['type'] != null && decoded['coordinates'] != null) return [decoded];
      }
    } catch (_) {}
    return const [];
  }

  void _drawTargets(Canvas canvas, Size size) {
    final textPainter = TextPainter(textDirection: TextDirection.ltr, textAlign: TextAlign.center);
    for (final target in targets) {
      final p = project(target.latitude, target.longitude, size);
      final ipi = target.scores['IPI'] ?? 0;
      final color = ipi >= 85 ? const Color(0xFFFFD700) : ipi >= 70 ? const Color(0xFF3DDC84) : ipi >= 55 ? const Color(0xFFFFB020) : const Color(0xFFFF4D4D);
      final glow = Paint()..color = color.withOpacity(0.16)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
      canvas.drawCircle(p, 22, glow);
      canvas.drawCircle(p, 10, Paint()..color = color.withOpacity(0.22));
      canvas.drawCircle(p, 7, Paint()..color = color.withOpacity(0.82));
      canvas.drawCircle(p, 10, Paint()..color = const Color(0xFF050806)..style = PaintingStyle.stroke..strokeWidth = 1.6);
      textPainter.text = TextSpan(text: target.id.replaceAll(RegExp(r'[^A-Z0-9]'), '').replaceAll('APP', '').replaceAll('OP', ''), style: const TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.w900));
      textPainter.layout(maxWidth: 32);
      textPainter.paint(canvas, Offset(p.dx - textPainter.width / 2, p.dy - textPainter.height / 2));
    }
  }

  void _drawLegend(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xCC101010);
    final rect = RRect.fromRectAndRadius(Rect.fromLTWH(12, size.height - 126, size.width - 24, 62), const Radius.circular(20));
    canvas.drawRRect(rect, paint);
    final tp = TextPainter(textDirection: TextDirection.rtl, textAlign: TextAlign.center);
    tp.text = const TextSpan(text: 'Offline Region Pack  |  Targets + AOI + Lineaments + User Layers', style: TextStyle(color: Color(0xFFFFD700), fontSize: 12, fontWeight: FontWeight.w700));
    tp.layout(maxWidth: size.width - 42);
    tp.paint(canvas, Offset(22, size.height - 104));
    tp.text = TextSpan(text: 'N ${north.toStringAsFixed(2)}  S ${south.toStringAsFixed(2)}  E ${east.toStringAsFixed(2)}  W ${west.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white60, fontSize: 11));
    tp.layout(maxWidth: size.width - 42);
    tp.paint(canvas, Offset(22, size.height - 82));
  }

  @override
  bool shouldRepaint(covariant _OfflineMapPainter oldDelegate) => oldDelegate.targets != targets || oldDelegate.layers != layers;
}
