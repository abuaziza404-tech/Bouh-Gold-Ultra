import 'package:flutter/material.dart';

import '../../domain/models/analysis_result.dart';

class AnalysisBottomSheet extends StatelessWidget {
  final AnalysisResult result;
  const AnalysisBottomSheet({super.key, required this.result});

  Color get _accent {
    if (result.isReject) return const Color(0xFFFF3030);
    if (result.isTargetB) return const Color(0xFFFFD700);
    if (result.outsidePack) return const Color(0xFF94A3B8);
    return const Color(0xFFFFB020);
  }

  @override
  Widget build(BuildContext context) {
    final cell = result.cell;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF06100A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(34)),
        ),
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(child: Container(width: 92, height: 5, decoration: BoxDecoration(color: _accent.withOpacity(0.75), borderRadius: BorderRadius.circular(100)))),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: _accent.withOpacity(0.65), width: 1.3),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(result.title, style: TextStyle(color: _accent, fontSize: 28, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(cell == null ? 'نقطة غير مربوطة بخلية' : '${cell.name} — ${cell.belt}', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text('المسافة إلى أقرب خلية: ${result.distanceMeters.toStringAsFixed(1)} متر', style: const TextStyle(color: Color(0xFFCAD5CA))),
                  if (cell != null) Text('المصدر: ${cell.sourceGroup} / ${cell.source}', style: const TextStyle(color: Color(0xFF9CA3AF))),
                ]),
              ),
              const SizedBox(height: 16),
              _scoreRow(),
              const SizedBox(height: 16),
              _section('قرار المحرك', result.explanation),
              _section('بوابات القتل المفعلة', result.triggeredGates.isEmpty ? 'لا توجد بوابات رفض صارمة.' : result.triggeredGates.join('  •  ')),
              _section('المؤشرات الطيفية', _spectralText()),
              _section('GPZ 7000', 'Ground: ${result.gpz.groundType}\nMode: ${result.gpz.goldMode}\nSensitivity: ${result.gpz.sensitivity}\nAudio: ${result.gpz.audioSmoothing}\nSwing: ${result.gpz.swingStrategy}\n${result.gpz.reason}'),
              if (cell != null) _section('ملاحظة السجل', cell.note),
              const SizedBox(height: 14),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scoreRow() {
    return Row(children: [
      Expanded(child: _scoreBox('Decision', result.decision)),
      const SizedBox(width: 10),
      Expanded(child: _scoreBox('IPI', result.ipi.toStringAsFixed(1))),
      const SizedBox(width: 10),
      Expanded(child: _scoreBox('P-Score', result.pScore.toStringAsFixed(1))),
    ]);
  }

  Widget _scoreBox(String label, String value) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _accent.withOpacity(0.45)), color: const Color(0xFF0B160E)),
    child: Column(children: [Text(label, style: const TextStyle(color: Color(0xFF9CA3AF), fontSize: 12)), const SizedBox(height: 6), Text(value, textAlign: TextAlign.center, style: TextStyle(color: _accent, fontWeight: FontWeight.w900, fontSize: 18))]),
  );

  Widget _section(String title, String body) => Container(
    margin: const EdgeInsets.only(top: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: const Color(0xFF0A120C), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF1F3B29))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: TextStyle(color: _accent, fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 8), Text(body, style: const TextStyle(color: Colors.white70, height: 1.55))]),
  );

  String _spectralText() {
    final s = result.spectral;
    if (!s.hasRawBands) return s.note;
    String f(double? v) => v == null ? 'غير متاح' : v.toStringAsFixed(4);
    return 'Iron B4/B2: ${f(s.ironIndex)}\nQuartz B11/B12: ${f(s.quartzIndex)}\nAlteration: ${f(s.alterationIndex)}\nNDMI: ${f(s.ndmi)}\n${s.note}';
  }
}
