import 'dart:convert';

import 'package:flutter/material.dart';

import '../../data/repositories/analysis_repository.dart';
import '../../data/repositories/workspace_repository.dart';
import '../../domain/models/analysis_result.dart';
import '../../domain/models/assistant_message.dart';
import '../../domain/models/field_log.dart';
import '../../domain/models/map_layer.dart';
import '../../domain/models/prediction_candidate.dart';
import '../../domain/models/target_cell.dart';
import '../../engines/export_engine.dart';
import '../../engines/local_ai_assistant_engine.dart';
import '../../engines/predictive_engine.dart';

class AppController extends ChangeNotifier {
  final AnalysisRepository analysisRepository;
  final WorkspaceRepository workspaceRepository;
  late final PredictiveEngine predictiveEngine;
  late final LocalAiAssistantEngine assistantEngine;
  late final ExportEngine exportEngine;

  bool loading = true;
  String? error;
  AnalysisResult? lastResult;
  String sortMode = 'ipi';
  int tabIndex = 0;
  List<PredictionCandidate> predictions = [];
  String lastExportPath = '';

  AppController({required this.analysisRepository, required this.workspaceRepository}) {
    predictiveEngine = PredictiveEngine();
    assistantEngine = LocalAiAssistantEngine(predictiveEngine);
    exportEngine = ExportEngine(workspaceRepository.storage);
  }

  Future<void> bootstrap() async {
    try {
      await analysisRepository.load();
      await workspaceRepository.load();
      predictions = predictiveEngine.generateCandidates(analysisRepository.cells, limit: 12);
      if (workspaceRepository.messages.isEmpty) {
        await sendAssistantCommand('عرّف النظام');
      }
    } catch (e) {
      error = '$e';
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  List<TargetCell> get targets {
    final list = [...analysisRepository.cells];
    if (sortMode == 'pscore') {
      list.sort((a, b) => (b.scores['PScore'] ?? 0).compareTo(a.scores['PScore'] ?? 0));
    } else if (sortMode == 'nearest') {
      list.sort((a, b) => a.id.compareTo(b.id));
    } else if (sortMode == 'elite') {
      list.sort((a, b) => _eliteScore(b).compareTo(_eliteScore(a)));
    } else {
      list.sort((a, b) => (b.scores['IPI'] ?? 0).compareTo(a.scores['IPI'] ?? 0));
    }
    return list;
  }

  List<MapLayer> get layers => workspaceRepository.layers;
  List<AssistantMessage> get messages => workspaceRepository.messages;

  List<MapLayer> get allDrawableLayers {
    final builtins = <MapLayer>[];
    final aoi = analysisRepository.aoi;
    final lineaments = analysisRepository.lineaments;
    builtins.add(MapLayer(id: 'builtin_aoi', name: 'AOI Regions', type: 'geojson', source: 'asset', enabled: true, featureCount: ((aoi['features'] as List?) ?? const []).length, content: _stringify(aoi), createdAt: DateTime.now()));
    builtins.add(MapLayer(id: 'builtin_lineaments', name: 'Lineaments', type: 'geojson', source: 'asset', enabled: true, featureCount: ((lineaments['features'] as List?) ?? const []).length, content: _stringify(lineaments), createdAt: DateTime.now()));
    builtins.addAll(layers);
    return builtins.where((l) => l.enabled).toList(growable: false);
  }

  void setTab(int index) {
    tabIndex = index;
    notifyListeners();
  }

  void setSortMode(String mode) {
    sortMode = mode;
    notifyListeners();
  }

  AnalysisResult analyze(double lat, double lon) {
    final result = analysisRepository.analyzePoint(lat, lon);
    lastResult = result;
    notifyListeners();
    return result;
  }

  Future<void> createFieldLog(String observation) async {
    final r = lastResult;
    if (r == null) return;
    await workspaceRepository.addFieldLog(FieldLog(
      id: 'log_${DateTime.now().millisecondsSinceEpoch}',
      targetId: r.cell?.id ?? 'manual_point',
      title: r.cell?.name ?? 'نقطة يدوية',
      latitude: r.tappedLatitude,
      longitude: r.tappedLongitude,
      observation: observation,
      decision: r.decision,
      createdAt: DateTime.now(),
    ));
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> addLayer(String name, String type, String content) async {
    await workspaceRepository.addLayerFromText(name: name, type: type, content: content);
    notifyListeners();
  }

  Future<void> toggleLayer(String id) async {
    await workspaceRepository.toggleLayer(id);
    notifyListeners();
  }

  Future<void> createProject(String name, String region, String description) async {
    await workspaceRepository.createProject(name, region, description);
    notifyListeners();
  }

  Future<void> sendAssistantCommand(String prompt) async {
    final now = DateTime.now();
    await workspaceRepository.addMessage(AssistantMessage(id: 'msg_u_${now.microsecondsSinceEpoch}', fromUser: true, text: prompt, createdAt: now));
    final reply = assistantEngine.answer(prompt: prompt, repository: analysisRepository, predictions: predictions, lastResult: lastResult);
    await workspaceRepository.addMessage(AssistantMessage(id: 'msg_ai_${DateTime.now().microsecondsSinceEpoch}', fromUser: false, text: reply, createdAt: DateTime.now()));
    notifyListeners();
  }

  void refreshPredictions() {
    predictions = predictiveEngine.generateCandidates(analysisRepository.cells, limit: 12);
    notifyListeners();
  }

  Future<void> exportCsv() async {
    lastExportPath = await exportEngine.exportTargetsCsv(targets);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> exportKml() async {
    lastExportPath = await exportEngine.exportTargetsKml(targets);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> exportPredictionsGeoJson() async {
    lastExportPath = await exportEngine.exportPredictionsGeoJson(predictions);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> saveSystemSnapshot() async {
    final text = StringBuffer()
      ..writeln('# BOUH GOLD PRO ULTRA v12.2 System Snapshot')
      ..writeln('Targets: ${targets.length}')
      ..writeln('Layers: ${workspaceRepository.layers.length}')
      ..writeln('Predictions: ${predictions.length}')
      ..writeln('Last Decision: ${lastResult?.decision ?? 'none'}')
      ..writeln('Rule: Structure → Pattern → Alteration → Confirmation → Decision');
    await workspaceRepository.writeSystemNote('system_snapshot', text.toString());
    notifyListeners();
  }

  double _eliteScore(TargetCell t) {
    final gates = t.gates;
    int active = 0;
    for (final k in ['structure', 'pattern', 'swir_clay', 'quartz_carrier', 'field_evidence']) {
      final v = '${gates[k] ?? ''}'.toLowerCase();
      if (v == 'yes' || v == 'partial') active++;
    }
    return ((t.scores['IPI'] ?? 0) * 2) + ((t.scores['PScore'] ?? 0) * 0.7) + active * 20;
  }

  String _stringify(Map<String, dynamic> map) => map.isEmpty ? '{}' : jsonEncode(map);
}
