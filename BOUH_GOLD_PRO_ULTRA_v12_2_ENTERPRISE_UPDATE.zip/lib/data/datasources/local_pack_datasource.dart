import 'dart:convert';

import 'package:flutter/services.dart';

class LocalPackDataSource {
  static const String base = 'assets/packs/red_sea_hills';

  Future<Map<String, dynamic>> loadManifest() async {
    final raw = await rootBundle.loadString('$base/pack_manifest.json');
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> loadKillMatrix() async {
    final raw = await rootBundle.loadString('$base/kill_matrix.json');
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> loadGridIndex() async {
    final raw = await rootBundle.loadString('$base/grid_index.json');
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> loadKnownSignatures() async {
    final raw = await rootBundle.loadString('$base/known_signatures.json');
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> loadAoiRegions() async {
    final raw = await rootBundle.loadString('$base/aoi_regions.geojson');
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> loadLineaments() async {
    final raw = await rootBundle.loadString('$base/lineaments.geojson');
    return jsonDecode(raw) as Map<String, dynamic>;
  }
}
