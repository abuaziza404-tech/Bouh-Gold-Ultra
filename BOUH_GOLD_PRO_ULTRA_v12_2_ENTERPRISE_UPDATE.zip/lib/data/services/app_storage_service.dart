import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

class AppStorageService {
  Directory? _root;

  Future<Directory> init() async {
    if (_root != null) return _root!;
    final docs = await getApplicationDocumentsDirectory();
    _root = Directory('${docs.path}/BOUH_GOLD_PRO_ULTRA_WORKSPACE');
    if (!await _root!.exists()) await _root!.create(recursive: true);
    for (final name in ['projects', 'layers', 'files', 'exports', 'logs', 'ai_memory', 'packs', 'systems']) {
      final dir = Directory('${_root!.path}/$name');
      if (!await dir.exists()) await dir.create(recursive: true);
    }
    return _root!;
  }

  Future<File> file(String relativePath) async {
    final root = await init();
    final file = File('${root.path}/$relativePath');
    final parent = file.parent;
    if (!await parent.exists()) await parent.create(recursive: true);
    return file;
  }

  Future<List<Map<String, dynamic>>> readList(String relativePath) async {
    final f = await file(relativePath);
    if (!await f.exists()) return [];
    final raw = await f.readAsString();
    if (raw.trim().isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is List) return decoded.cast<Map<String, dynamic>>();
    return [];
  }

  Future<void> writeList(String relativePath, List<Map<String, dynamic>> rows) async {
    final f = await file(relativePath);
    await f.writeAsString(const JsonEncoder.withIndent('  ').convert(rows));
  }

  Future<Map<String, dynamic>> readMap(String relativePath) async {
    final f = await file(relativePath);
    if (!await f.exists()) return {};
    final raw = await f.readAsString();
    if (raw.trim().isEmpty) return {};
    final decoded = jsonDecode(raw);
    if (decoded is Map<String, dynamic>) return decoded;
    return {};
  }

  Future<void> writeText(String relativePath, String content) async {
    final f = await file(relativePath);
    await f.writeAsString(content);
  }

  Future<String> readText(String relativePath) async {
    final f = await file(relativePath);
    if (!await f.exists()) return '';
    return f.readAsString();
  }

  Future<List<FileSystemEntity>> listFolder(String relativeFolder) async {
    final root = await init();
    final dir = Directory('${root.path}/$relativeFolder');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir.list().toList();
  }

  Future<int> workspaceBytes() async {
    final root = await init();
    var total = 0;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File) total += await entity.length();
    }
    return total;
  }

  Future<String> rootPath() async => (await init()).path;
}
