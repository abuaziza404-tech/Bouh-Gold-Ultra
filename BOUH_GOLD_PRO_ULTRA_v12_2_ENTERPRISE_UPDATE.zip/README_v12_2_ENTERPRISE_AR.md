# BOUH GOLD PRO ULTRA v12.2 Enterprise Workspace

هذه نسخة تحديث تطبيق حقيقية أكثر اتساعًا من v12.1. صُممت للعمل Offline-first على Android و iOS No-CodeSign، مع مساحة داخلية لإدارة المشاريع والطبقات والملفات والصادرات ومساعد BOUH المحلي.

## ما الجديد
- Home Shell كامل بستة تبويبات: الخريطة، التنبؤ، الطبقات، الملفات، AI، النظام.
- خريطة Offline Canvas لا تعتمد على الإنترنت.
- رسم AOI وLineaments وTargets وطبقات GeoJSON المضافة يدويًا.
- مدير طبقات داخلي مع حفظ GeoJSON/KML داخل مساحة التطبيق.
- مدير ملفات وصادرات KML/CSV/GeoJSON.
- مساعد BOUH AI محلي Offline: Rule/Retrieval Engine وليس AI سحابيًا.
- محرك تنبؤ محافظ يفرز المواقع بناءً على Structure/Pattern/SWIR/Field Evidence.
- Workspace داخلي عبر path_provider لإنشاء مشاريع وملفات وسجلات ولقطات نظام.
- استمرار حماية Distance Guard لمنع تحليل خلية بعيدة مثل 32 كم.

## الحدود العلمية
- التطبيق لا يدعي إثباتًا اقتصاديًا للذهب.
- لا يوجد Target-B نهائي دون Field Validation + Assay + QA/QC.
- إذا لم تتوفر باندات خام، تبقى SWIR/Clay في حالة HOLD.

## طريقة الرفع
ارفع ZIP إلى GitHub بدل القديم، ثم شغّل Actions، وحمّل APK من Artifacts أو Releases.
